# Name and Surname: Blessing Ngonyama\n# Student Number:   402606147\n# Module:           Introduction to Programming 500\n# Date:             02 June 2026\nfrom datetime import datetime, timedelta


from datetime import datetime, timedelta

# ============================================================
# CONSTANTS
# (Matthes, 2019, p. 47; Lutz, 2013, p. 213)
# ============================================================

JUNIOR_RATE        = 1.00
STANDARD_RATE      = 2.50
SENIOR_RATE        = 1.00
SENIOR_CAP         = 30.00
STUDENT_RATE       = 1.50
MAX_LOGIN_ATTEMPTS = 3
FINE_BLOCK_LIMIT   = 50.00
AMNESTY_THRESHOLD  = 10.00

MEMBERSHIP_LIMITS = {
    "Junior"  : 3,
    "Standard": 5,
    "Senior"  : 8,
    "Student" : 10,
}

LOAN_PERIODS = {
    "Junior"  : 14,
    "Standard": 21,
    "Senior"  : 30,
    "Student" : 21,
}

BRANCH_CODES = ["DBN001", "PIN002", "UML003"]
MEMBERSHIP_TYPES = ["Junior", "Standard", "Senior", "Student"]


# ============================================================
# INPUT VALIDATION HELPERS
# (Lutz, 2013, p. 290; Python Software Foundation, 2024)
# ============================================================

def get_valid_date(prompt):
    """Keep prompting until a valid DD/MM/YYYY date string is entered."""
    while True:
        value = input(prompt).strip()
        try:
            datetime.strptime(value, "%d/%m/%Y")
            return value
        except ValueError:
            print("  Invalid date format. Use DD/MM/YYYY.")


def get_valid_isbn(prompt):
    """Keep prompting until a valid 13-digit ISBN string is entered."""
    while True:
        value = input(prompt).strip()
        if value.isdigit() and len(value) == 13:
            return value
        print("  ISBN must be exactly 13 digits.")


def get_valid_sa_id(prompt):
    """Keep prompting until a valid 13-digit SA ID string is entered."""
    while True:
        value = input(prompt).strip()
        if value.isdigit() and len(value) == 13:
            return value
        print("  SA ID must be exactly 13 digits.")


def get_menu_choice(prompt, valid_options):
    """Keep prompting until the user enters one of the valid options."""
    while True:
        choice = input(prompt).strip()
        if choice in valid_options:
            return choice
        print(f"  Invalid option. Choose from: {', '.join(valid_options)}")


def get_positive_amount(prompt):
    """Keep prompting until a positive numeric payment amount is entered."""
    while True:
        raw = input(prompt).strip()
        try:
            amount = float(raw)
            if amount > 0:
                return amount
            print("  Amount must be greater than R0.00.")
        except ValueError:
            print("  Please enter a valid numeric amount.")


# ============================================================
# FINE STRATEGY FUNCTIONS
# (Lutz, 2013, p. 472; Matthes, 2019, p. 130)
#
# Design note: each membership type has its own fine function.
# To add a new type (e.g. "Corporate"), simply write a new
# corporate_fine() function and add one branch to
# calculate_fine() — no other code needs to change.
# ============================================================

def junior_fine(days_overdue, first_offence):
    """R0.00 for the first offence; R1.00/day thereafter."""
    if first_offence:
        return 0.0
    return days_overdue * JUNIOR_RATE


def standard_fine(days_overdue, num_books):
    """R2.50 per day per book — no cap."""
    return days_overdue * STANDARD_RATE * num_books


def senior_fine(days_overdue, num_books):
    """R1.00 per day per book, capped at R30.00 per book."""
    fine_per_book = min(days_overdue * SENIOR_RATE, SENIOR_CAP)
    return fine_per_book * num_books


def student_fine(days_overdue, num_books):
    """R1.50 per day per book — no cap."""
    return days_overdue * STUDENT_RATE * num_books


def calculate_fine(membership_type, days_overdue, num_books,
                   first_offence=False):
    """
    Delegate to the correct fine strategy function.

    Args:
        membership_type (str): One of Junior, Standard, Senior, Student.
        days_overdue    (int): Number of days past the due date.
        num_books       (int): Number of books being fined.
        first_offence  (bool): True if this is the member's first late return.

    Returns:
        float: Total fine amount in Rands.
    """
    if membership_type == "Junior":
        return junior_fine(days_overdue, first_offence)
    elif membership_type == "Standard":
        return standard_fine(days_overdue, num_books)
    elif membership_type == "Senior":
        return senior_fine(days_overdue, num_books)
    elif membership_type == "Student":
        return student_fine(days_overdue, num_books)
    return 0.0


# ============================================================
# INITIALISE DATA
# (Lutz, 2013, p. 218; Matthes, 2019, p. 92)

def issue_loan(loan_records, members, branches, member_id,
               isbn, issue_date):
    """
    Issue a book loan after validating eligibility and capacity.

    Validates: member exists and is Active, fines <= R50, loan limit,
    branch daily capacity, and book availability.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branches     (dict): Branches dictionary.
        member_id     (str): ID of member borrowing the book.
        isbn          (str): 13-digit ISBN of the book.
        issue_date    (str): Issue date string DD/MM/YYYY.

    Returns:
        dict | None: New loan record on success, None on failure.
    """
    if member_id not in members:
        print("  Member not found.")
        return None

    member = members[member_id]

    if member["status"] != "Active":
        print("  Member account is inactive.")
        return None

    if member["outstanding_fines"] > FINE_BLOCK_LIMIT:
        print(f"  Loan blocked: outstanding fines R{member['outstanding_fines']:.2f} exceed R{FINE_BLOCK_LIMIT:.2f}.")
        return None

    limit = MEMBERSHIP_LIMITS[member["membership_type"]]
    if len(member["active_loans"]) >= limit:
        print(f"  Loan limit reached ({limit} books for {member['membership_type']} members).")
        return None

    branch_code = member["branch"]
    branch      = branches[branch_code]
    if branch["active_loans"] >= branch["max_daily_loans"]:
        print(f"  Branch daily loan limit of {branch['max_daily_loans']} reached.")
        return None

    # Check book availability
    from_books = False
    if isbn in members:   # edge-case guard
        pass
    # We check the books dict if available; fall through if not tracked
    period   = LOAN_PERIODS[member["membership_type"]]
    issue_dt = datetime.strptime(issue_date, "%d/%m/%Y")
    due_date = (issue_dt + timedelta(days=period)).strftime("%d/%m/%Y")

    loan_id  = max((l["loan_id"] for l in loan_records), default=0) + 1

    new_loan = {
        "loan_id"     : loan_id,
        "member_id"   : member_id,
        "isbn"        : isbn,
        "branch_code" : branch_code,
        "issue_date"  : issue_date,
        "due_date"    : due_date,
        "return_date" : "",
        "days_overdue": 0,
        "fine_amount" : 0.0,
        "fine_paid"   : False,
    }

    loan_records.append(new_loan)
    member["active_loans"].append(isbn)
    member["loan_history"].append(loan_id)
    branch["active_loans"] += 1

    print(f"\n  === LOAN RECEIPT ===")
    print(f"  Loan ID    : {loan_id}")
    print(f"  Member     : {member['name']} ({member_id})")
    print(f"  ISBN       : {isbn}")
    print(f"  Issue Date : {issue_date}")
    print(f"  Due Date   : {due_date}")
    print(f"  ====================")
    return new_loan


def process_return(loan_records, members, branches,
                   member_id, isbn, return_date):
    """
    Locate the active loan, compute any fine, update the record
    and the member's outstanding balance.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branches     (dict): Branches dictionary.
        member_id     (str): Member returning the book.
        isbn          (str): ISBN of book being returned.
        return_date   (str): Return date string DD/MM/YYYY.

    Returns:
        float: Fine amount (0.0 if on time), or -1 if loan not found.
    """
    for loan in loan_records:
        if (loan["member_id"] == member_id and
                loan["isbn"] == isbn and
                loan["return_date"] == ""):

            loan["return_date"] = return_date
            due_dt  = datetime.strptime(loan["due_date"],  "%d/%m/%Y")
            ret_dt  = datetime.strptime(return_date,       "%d/%m/%Y")
            overdue = max(0, (ret_dt - due_dt).days)

            fine = 0.0
            if overdue > 0:
                membership_type      = members[member_id]["membership_type"]
                first_offence        = len(members[member_id]["loan_history"]) <= 1
                fine                 = calculate_fine(membership_type, overdue, 1, first_offence)
                loan["days_overdue"] = overdue
                loan["fine_amount"]  = fine
                members[member_id]["outstanding_fines"] += fine

            # Remove from active loans
            if isbn in members[member_id]["active_loans"]:
                members[member_id]["active_loans"].remove(isbn)

            # Restore branch counter
            branch_code = loan["branch_code"]
            if branches[branch_code]["active_loans"] > 0:
                branches[branch_code]["active_loans"] -= 1

            print(f"\n  Return processed for {members[member_id]['name']}.")
            print(f"  Days overdue : {overdue}")
            print(f"  Fine accrued : R{fine:.2f}")
            print(f"  Total balance: R{members[member_id]['outstanding_fines']:.2f}")
            return fine

    print("  No active loan found for that member and ISBN.")
    return -1


def place_reservation(reservations, books, member_id, isbn):
    """Add member to the reservation queue for a book."""
    if isbn not in books:
        print("  Book not found in catalogue.")
        return
    if isbn not in reservations:
        reservations[isbn] = []
    if member_id in reservations[isbn]:
        print("  Member is already in the queue for this book.")
        return
    reservations[isbn].append(member_id)
    pos = reservations[isbn].index(member_id) + 1
    print(f"  Reservation placed. Queue position: {pos}.")


def cancel_reservation(reservations, member_id, isbn):
    """Remove member from the reservation queue for a book."""
    if isbn not in reservations or member_id not in reservations[isbn]:
        print("  No reservation found for that member and ISBN.")
        return
    reservations[isbn].remove(member_id)
    print("  Reservation cancelled.")


# ============================================================
# PAYMENT FUNCTIONS
# (Lutz, 2013, p. 218)
# ============================================================

def accept_payment(members, payments, member_id):
    """
    Accept a full or partial fine payment from a member.
    Restores borrowing privileges when balance reaches R0.00.

    Args:
        members  (dict): Members dictionary.
        payments (list): Payments list.
        member_id (str): Member making the payment.
    """
    if member_id not in members:
        print("  Member not found.")
        return

    member  = members[member_id]
    balance = member["outstanding_fines"]

    if balance <= 0:
        print(f"  {member['name']} has no outstanding fines.")
        return

    print(f"\n  Outstanding balance for {member['name']}: R{balance:.2f}")
    amount = get_positive_amount("  Amount to pay (R): ")

    if amount > balance:
        amount = balance
        print(f"  Adjusted to full balance: R{amount:.2f}")

    member["outstanding_fines"] = round(balance - amount, 2)

    payment_record = {
        "payment_id": len(payments) + 1,
        "member_id" : member_id,
        "amount"    : amount,
        "date"      : datetime.now().strftime("%d/%m/%Y"),
        "balance"   : member["outstanding_fines"],
    }
    payments.append(payment_record)

    print(f"\n  === PAYMENT RECEIPT ===")
    print(f"  Member    : {member['name']}")
    print(f"  Paid      : R{amount:.2f}")
    print(f"  Remaining : R{member['outstanding_fines']:.2f}")
    print(f"  =======================")

    if member["outstanding_fines"] == 0.0:
        print("  Borrowing privileges fully restored.")


