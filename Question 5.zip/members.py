# Name and Surname: Blessing Ngonyama\n# Student Number:   402606147\n# Module:           Introduction to Programming 500\n# Date:             02 June 2026\nfrom datetime import datetime

def authenticate_staff(staff_accounts, username, password):
    """
    Validate staff credentials.

    Args:
        staff_accounts (dict): Staff accounts dictionary.
        username       (str):  Entered username.
        password       (str):  Entered password.

    Returns:
        dict | None: Staff record on success, None on failure.

    Test:
        >>> authenticate_staff({"u": {"password":"p","role":"Librarian","full_name":"A","branch":"DBN001","active":True}}, "u", "p")
        {'password': 'p', 'role': 'Librarian', 'full_name': 'A', 'branch': 'DBN001', 'active': True}
        >>> authenticate_staff({...}, "u", "wrong") -> None
    """
    if username in staff_accounts:
        account = staff_accounts[username]
        if not account.get("active", True):
            print("  This account has been deactivated.")
            return None
        if account["password"] == password:
            return account
    return None


# ============================================================
# MEMBER FUNCTIONS
# (Matthes, 2019, p. 56; Lutz, 2013, p. 312)
# ============================================================

def register_member(members, member_id, name, sa_id, contact,
                    email, branch, membership_type):
    """
    Register a new library member.  Rejects duplicate SA IDs and
    duplicate member IDs.

    Args:
        members         (dict): Members dictionary.
        member_id        (str): Unique member ID (e.g. "M011").
        name             (str): Full name.
        sa_id            (str): 13-digit SA ID number.
        contact          (str): Contact number.
        email            (str): Email address.
        branch           (str): Branch code.
        membership_type  (str): One of Junior, Standard, Senior, Student.

    Returns:
        dict | None: New member record on success, None on failure.
    """
    # Reject duplicate member ID
    if member_id in members:
        print(f"  Member ID '{member_id}' already exists.")
        return None
    # Reject duplicate SA ID
    for existing in members.values():
        if existing["sa_id"] == sa_id:
            print("  A member with that SA ID already exists.")
            return None
    members[member_id] = {
        "name"             : name,
        "sa_id"            : sa_id,
        "contact"          : contact,
        "email"            : email,
        "branch"           : branch,
        "membership_type"  : membership_type,
        "status"           : "Active",
        "active_loans"     : [],
        "outstanding_fines": 0.0,
        "loan_history"     : [],
    }
    print(f"\n  Member '{name}' registered successfully (ID: {member_id}).")
    return members[member_id]


def list_membership_types(members):
    """Display all unique membership types present in the system using a set."""
    types_in_use = {m["membership_type"] for m in members.values()}
    print("\n  Membership types currently in use:")
    for t in sorted(types_in_use):
        print(f"    - {t}")


def view_member_account(members, loan_records, reservations, member_id):
    """
    Display complete account information for a member:
    loan history, active loans, outstanding fines, and
    reservation queue positions.
    """
    if member_id not in members:
        print("  Member not found.")
        return
    m = members[member_id]
    print(f"\n  ---- Member Account: {m['name']} ({member_id}) ----")
    print(f"  Membership : {m['membership_type']}  |  Branch : {m['branch']}")
    print(f"  Status     : {m['status']}  |  Outstanding fines: R{m['outstanding_fines']:.2f}")

    print("\n  Loan History:")
    history = [l for l in loan_records if l["member_id"] == member_id]
    if not history:
        print("    No loans on record.")
    else:
        for loan in history:
            status = "Active" if loan["return_date"] == "" else f"Returned {loan['return_date']}"
            print(f"    Loan {loan['loan_id']:>3} | ISBN {loan['isbn']} | "
                  f"Due {loan['due_date']} | {status} | "
                  f"Fine R{loan['fine_amount']:.2f} "
                  f"({'Paid' if loan['fine_paid'] else 'Unpaid'})")

    print("\n  Reservation Queue Positions:")
    found_res = False
    for isbn, queue in reservations.items():
        if member_id in queue:
            pos = queue.index(member_id) + 1
            print(f"    ISBN {isbn} — Position {pos} in queue")
            found_res = True
    if not found_res:
        print("    No active reservations.")


