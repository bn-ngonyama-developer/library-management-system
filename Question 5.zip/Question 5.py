
# ============================================================
# Name and Surname: Blessing Ngonyama
# Student Number:   402606147
# Module:           Introduction to Programming 500
# Date:             02 June 2026
# ============================================================

# ============================================================
# QUESTION 5 — Structuring Multi-Function Programs
# Complete Integrated Library Management System
# Thekwini Metropolitan Libraries (EML)
# ============================================================

from datetime import datetime, timedelta

# ============================================================
# CONSTANTS
# (Matthes, 2019, p. 47; Lutz, 2013, p. 213)
# ============================================================

JUNIOR_RATE        = 1.00
STANDARD_RATE      = 2.50
SENIOR_RATE        = 1.00
SENIOR_CAP         = 30.00
STUDENT_RATE       = 1.50
MAX_LOGIN_ATTEMPTS = 3
FINE_BLOCK_LIMIT   = 50.00
AMNESTY_THRESHOLD  = 10.00

MEMBERSHIP_LIMITS = {
    "Junior"  : 3,
    "Standard": 5,
    "Senior"  : 8,
    "Student" : 10,
}

LOAN_PERIODS = {
    "Junior"  : 14,
    "Standard": 21,
    "Senior"  : 30,
    "Student" : 21,
}

BRANCH_CODES = ["DBN001", "PIN002", "UML003"]
MEMBERSHIP_TYPES = ["Junior", "Standard", "Senior", "Student"]


# ============================================================
# INPUT VALIDATION HELPERS
# (Lutz, 2013, p. 290; Python Software Foundation, 2024)
# ============================================================

def get_valid_date(prompt):
    """Keep prompting until a valid DD/MM/YYYY date string is entered."""
    while True:
        value = input(prompt).strip()
        try:
            datetime.strptime(value, "%d/%m/%Y")
            return value
        except ValueError:
            print("  Invalid date format. Use DD/MM/YYYY.")


def get_valid_isbn(prompt):
    """Keep prompting until a valid 13-digit ISBN string is entered."""
    while True:
        value = input(prompt).strip()
        if value.isdigit() and len(value) == 13:
            return value
        print("  ISBN must be exactly 13 digits.")


def get_valid_sa_id(prompt):
    """Keep prompting until a valid 13-digit SA ID string is entered."""
    while True:
        value = input(prompt).strip()
        if value.isdigit() and len(value) == 13:
            return value
        print("  SA ID must be exactly 13 digits.")


def get_menu_choice(prompt, valid_options):
    """Keep prompting until the user enters one of the valid options."""
    while True:
        choice = input(prompt).strip()
        if choice in valid_options:
            return choice
        print(f"  Invalid option. Choose from: {', '.join(valid_options)}")


def get_positive_amount(prompt):
    """Keep prompting until a positive numeric payment amount is entered."""
    while True:
        raw = input(prompt).strip()
        try:
            amount = float(raw)
            if amount > 0:
                return amount
            print("  Amount must be greater than R0.00.")
        except ValueError:
            print("  Please enter a valid numeric amount.")


# ============================================================
# FINE STRATEGY FUNCTIONS
# (Lutz, 2013, p. 472; Matthes, 2019, p. 130)
#
# Design note: each membership type has its own fine function.
# To add a new type (e.g. "Corporate"), simply write a new
# corporate_fine() function and add one branch to
# calculate_fine() — no other code needs to change.
# ============================================================

def junior_fine(days_overdue, first_offence):
    """R0.00 for the first offence; R1.00/day thereafter."""
    if first_offence:
        return 0.0
    return days_overdue * JUNIOR_RATE


def standard_fine(days_overdue, num_books):
    """R2.50 per day per book — no cap."""
    return days_overdue * STANDARD_RATE * num_books


def senior_fine(days_overdue, num_books):
    """R1.00 per day per book, capped at R30.00 per book."""
    fine_per_book = min(days_overdue * SENIOR_RATE, SENIOR_CAP)
    return fine_per_book * num_books


def student_fine(days_overdue, num_books):
    """R1.50 per day per book — no cap."""
    return days_overdue * STUDENT_RATE * num_books


def calculate_fine(membership_type, days_overdue, num_books,
                   first_offence=False):
    """
    Delegate to the correct fine strategy function.

    Args:
        membership_type (str): One of Junior, Standard, Senior, Student.
        days_overdue    (int): Number of days past the due date.
        num_books       (int): Number of books being fined.
        first_offence  (bool): True if this is the member's first late return.

    Returns:
        float: Total fine amount in Rands.
    """
    if membership_type == "Junior":
        return junior_fine(days_overdue, first_offence)
    elif membership_type == "Standard":
        return standard_fine(days_overdue, num_books)
    elif membership_type == "Senior":
        return senior_fine(days_overdue, num_books)
    elif membership_type == "Student":
        return student_fine(days_overdue, num_books)
    return 0.0


# ============================================================
# INITIALISE DATA
# (Lutz, 2013, p. 218; Matthes, 2019, p. 92)
# All structures are pre-populated with sample data at startup.
# Minimum: 10 members, 20 books, 15 loans across branches.
# ============================================================

def initialise_data():
    """
    Initialise and return all in-memory data structures with
    sample data.  Called once at startup.

    Returns:
        dict: Keys are members, staff_accounts, branches, books,
              loan_records, payments, reservations, security_log.
    """

    # --------------------------------------------------------
    # BRANCHES
    # --------------------------------------------------------
    branches = {
        "DBN001": {
            "name"            : "Durban Central Library",
            "address"         : "45 Anton Lembede St, Durban CBD",
            "librarian"       : "Mr. Ngonyama",
            "catalogue_size"  : 12000,
            "max_daily_loans" : 50,
            "active_loans"    : 0,
        },
        "PIN002": {
            "name"            : "Pinetown Public Library",
            "address"         : "41 Kings Road, Pinetown",
            "librarian"       : "Mr. Thwala",
            "catalogue_size"  : 7500,
            "max_daily_loans" : 30,
            "active_loans"    : 0,
        },
        "UML003": {
            "name"            : "Umlazi Community Library",
            "address"         : "Section V, Umlazi Township",
            "librarian"       : "Ms. Dlamini",
            "catalogue_size"  : 5800,
            "max_daily_loans" : 20,
            "active_loans"    : 0,
        },
    }

    # --------------------------------------------------------
    # STAFF ACCOUNTS  (one per role)
    # --------------------------------------------------------
    staff_accounts = {
        "librarian1": {
            "password" : "lib123",
            "role"     : "Librarian",
            "full_name": "Mr. Blessing Ngonyama",
            "branch"   : "DBN001",
            "active"   : True,
        },
        "senior1": {
            "password" : "sen123",
            "role"     : "Senior Librarian",
            "full_name": "Mr. Siphamandla Thwala",
            "branch"   : "PIN002",
            "active"   : True,
        },
        "admin1": {
            "password" : "admin123",
            "role"     : "System Administrator",
            "full_name": "Mrs. Zanele Peterson",
            "branch"   : "UML003",
            "active"   : True,
        },
    }

    # --------------------------------------------------------
    # MEMBERS  (minimum 10)
    # --------------------------------------------------------
    members = {
        "M001": {
            "name"             : "Sipho Dlamini",
            "sa_id"            : "0101015800087",
            "contact"          : "0812345678",
            "email"            : "sipho@gmail.com",
            "branch"           : "DBN001",
            "membership_type"  : "Student",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M002": {
            "name"             : "Ayanda Nkosi",
            "sa_id"            : "9505105800083",
            "contact"          : "0823456789",
            "email"            : "ayanda@gmail.com",
            "branch"           : "PIN002",
            "membership_type"  : "Standard",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 20.00,
            "loan_history"     : [],
        },
        "M003": {
            "name"             : "Bongani Zulu",
            "sa_id"            : "8803065800081",
            "contact"          : "0834567890",
            "email"            : "bongani@gmail.com",
            "branch"           : "UML003",
            "membership_type"  : "Junior",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M004": {
            "name"             : "Thandi Mthembu",
            "sa_id"            : "7712125800089",
            "contact"          : "0845678901",
            "email"            : "thandi@gmail.com",
            "branch"           : "DBN001",
            "membership_type"  : "Senior",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 5.00,
            "loan_history"     : [],
        },
        "M005": {
            "name"             : "Lungelo Khumalo",
            "sa_id"            : "0205015800085",
            "contact"          : "0856789012",
            "email"            : "lungelo@gmail.com",
            "branch"           : "PIN002",
            "membership_type"  : "Junior",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M006": {
            "name"             : "Nomsa Cele",
            "sa_id"            : "9209095800082",
            "contact"          : "0867890123",
            "email"            : "nomsa@gmail.com",
            "branch"           : "UML003",
            "membership_type"  : "Standard",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M007": {
            "name"             : "Sandile Mkhize",
            "sa_id"            : "8506065800086",
            "contact"          : "0878901234",
            "email"            : "sandile@gmail.com",
            "branch"           : "DBN001",
            "membership_type"  : "Student",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 60.00,
            "loan_history"     : [],
        },
        "M008": {
            "name"             : "Priya Naidoo",
            "sa_id"            : "9911115800084",
            "contact"          : "0889012345",
            "email"            : "priya@gmail.com",
            "branch"           : "PIN002",
            "membership_type"  : "Standard",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M009": {
            "name"             : "Rajesh Pillay",
            "sa_id"            : "6304045800080",
            "contact"          : "0890123456",
            "email"            : "rajesh@gmail.com",
            "branch"           : "UML003",
            "membership_type"  : "Senior",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
        "M010": {
            "name"             : "Lindiwe Shabalala",
            "sa_id"            : "0308085800088",
            "contact"          : "0801234567",
            "email"            : "lindiwe@gmail.com",
            "branch"           : "DBN001",
            "membership_type"  : "Student",
            "status"           : "Active",
            "active_loans"     : [],
            "outstanding_fines": 0.0,
            "loan_history"     : [],
        },
    }

    # --------------------------------------------------------
    # BOOKS  (dict keyed by ISBN; minimum 20)
    # --------------------------------------------------------
    books = {
        # --- DBN001 ---
        "9780143127550": {"title": "Long Walk to Freedom",    "author": "Nelson Mandela",    "branch": "DBN001", "copies_total": 4, "copies_available": 3},
        "9780143105428": {"title": "Disgrace",                "author": "J.M. Coetzee",      "branch": "DBN001", "copies_total": 3, "copies_available": 2},
        "9780006480235": {"title": "Things Fall Apart",       "author": "Chinua Achebe",     "branch": "DBN001", "copies_total": 5, "copies_available": 4},
        "9780374528379": {"title": "The God of Small Things", "author": "Arundhati Roy",     "branch": "DBN001", "copies_total": 2, "copies_available": 2},
        "9780679720201": {"title": "Crime and Punishment",    "author": "Fyodor Dostoevsky", "branch": "DBN001", "copies_total": 3, "copies_available": 3},
        "9780062316097": {"title": "The Alchemist",           "author": "Paulo Coelho",      "branch": "DBN001", "copies_total": 6, "copies_available": 5},
        "9780743273565": {"title": "The Great Gatsby",        "author": "F. Scott Fitzgerald","branch": "DBN001","copies_total": 4, "copies_available": 4},
        # --- PIN002 ---
        "9780451524935": {"title": "1984",                    "author": "George Orwell",     "branch": "PIN002", "copies_total": 5, "copies_available": 4},
        "9780316769174": {"title": "The Catcher in the Rye", "author": "J.D. Salinger",     "branch": "PIN002", "copies_total": 3, "copies_available": 3},
        "9780140449136": {"title": "Crime Fiction",           "author": "Various",           "branch": "PIN002", "copies_total": 2, "copies_available": 2},
        "9780385737951": {"title": "The Hunger Games",        "author": "Suzanne Collins",   "branch": "PIN002", "copies_total": 4, "copies_available": 3},
        "9780590353427": {"title": "Harry Potter Book 1",     "author": "J.K. Rowling",      "branch": "PIN002", "copies_total": 6, "copies_available": 5},
        "9780060935467": {"title": "To Kill a Mockingbird",   "author": "Harper Lee",        "branch": "PIN002", "copies_total": 3, "copies_available": 3},
        "9780060850524": {"title": "Brave New World",         "author": "Aldous Huxley",     "branch": "PIN002", "copies_total": 2, "copies_available": 2},
        # --- UML003 ---
        "9780671027032": {"title": "Rich Dad Poor Dad",       "author": "Robert Kiyosaki",   "branch": "UML003", "copies_total": 5, "copies_available": 4},
        "9781501156700": {"title": "It Ends with Us",         "author": "Colleen Hoover",    "branch": "UML003", "copies_total": 4, "copies_available": 3},
        "9780062409850": {"title": "The Martian",             "author": "Andy Weir",         "branch": "UML003", "copies_total": 3, "copies_available": 2},
        "9780385490818": {"title": "The Handmaid's Tale",     "author": "Margaret Atwood",   "branch": "UML003", "copies_total": 3, "copies_available": 3},
        "9780060731335": {"title": "Fahrenheit 451",          "author": "Ray Bradbury",      "branch": "UML003", "copies_total": 2, "copies_available": 2},
        "9780007420391": {"title": "The Hobbit",              "author": "J.R.R. Tolkien",    "branch": "UML003", "copies_total": 4, "copies_available": 3},
    }

    # --------------------------------------------------------
    # LOAN RECORDS  (minimum 15 across branches)
    # --------------------------------------------------------
    loan_records = [
        # DBN001 loans
        {"loan_id": 1,  "member_id": "M001", "isbn": "9780143127550", "branch_code": "DBN001", "issue_date": "01/04/2026", "due_date": "22/04/2026", "return_date": "20/04/2026", "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 2,  "member_id": "M007", "isbn": "9780143105428", "branch_code": "DBN001", "issue_date": "01/04/2026", "due_date": "22/04/2026", "return_date": "30/04/2026", "days_overdue": 8,  "fine_amount": 12.00, "fine_paid": False},
        {"loan_id": 3,  "member_id": "M004", "isbn": "9780006480235", "branch_code": "DBN001", "issue_date": "05/04/2026", "due_date": "05/05/2026", "return_date": "",           "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 4,  "member_id": "M010", "isbn": "9780374528379", "branch_code": "DBN001", "issue_date": "10/04/2026", "due_date": "01/05/2026", "return_date": "15/05/2026", "days_overdue": 14, "fine_amount": 21.00, "fine_paid": True},
        {"loan_id": 5,  "member_id": "M001", "isbn": "9780679720201", "branch_code": "DBN001", "issue_date": "15/04/2026", "due_date": "06/05/2026", "return_date": "",           "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        # PIN002 loans
        {"loan_id": 6,  "member_id": "M002", "isbn": "9780451524935", "branch_code": "PIN002", "issue_date": "01/04/2026", "due_date": "22/04/2026", "return_date": "25/04/2026", "days_overdue": 3,  "fine_amount":  7.50, "fine_paid": False},
        {"loan_id": 7,  "member_id": "M005", "isbn": "9780316769174", "branch_code": "PIN002", "issue_date": "03/04/2026", "due_date": "17/04/2026", "return_date": "17/04/2026", "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 8,  "member_id": "M008", "isbn": "9780385737951", "branch_code": "PIN002", "issue_date": "07/04/2026", "due_date": "28/04/2026", "return_date": "",           "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 9,  "member_id": "M002", "isbn": "9780590353427", "branch_code": "PIN002", "issue_date": "10/04/2026", "due_date": "01/05/2026", "return_date": "10/05/2026", "days_overdue": 9,  "fine_amount": 22.50, "fine_paid": True},
        {"loan_id": 10, "member_id": "M005", "isbn": "9780060935467", "branch_code": "PIN002", "issue_date": "12/04/2026", "due_date": "26/04/2026", "return_date": "30/04/2026", "days_overdue": 4,  "fine_amount":  4.00, "fine_paid": False},
        # UML003 loans
        {"loan_id": 11, "member_id": "M003", "isbn": "9780671027032", "branch_code": "UML003", "issue_date": "01/04/2026", "due_date": "15/04/2026", "return_date": "16/04/2026", "days_overdue": 1,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 12, "member_id": "M006", "isbn": "9781501156700", "branch_code": "UML003", "issue_date": "04/04/2026", "due_date": "25/04/2026", "return_date": "28/04/2026", "days_overdue": 3,  "fine_amount":  7.50, "fine_paid": False},
        {"loan_id": 13, "member_id": "M009", "isbn": "9780062409850", "branch_code": "UML003", "issue_date": "06/04/2026", "due_date": "06/05/2026", "return_date": "",           "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 14, "member_id": "M003", "isbn": "9780385490818", "branch_code": "UML003", "issue_date": "08/04/2026", "due_date": "22/04/2026", "return_date": "29/04/2026", "days_overdue": 7,  "fine_amount":  0.00, "fine_paid": False},
        {"loan_id": 15, "member_id": "M006", "isbn": "9780007420391", "branch_code": "UML003", "issue_date": "10/04/2026", "due_date": "01/05/2026", "return_date": "",           "days_overdue": 0,  "fine_amount":  0.00, "fine_paid": False},
    ]

    # Sync active_loans counters in branches and members from loan_records
    for loan in loan_records:
        if loan["return_date"] == "":
            branches[loan["branch_code"]]["active_loans"] += 1
            if loan["isbn"] not in members[loan["member_id"]]["active_loans"]:
                members[loan["member_id"]]["active_loans"].append(loan["isbn"])

    payments     = []
    reservations = {}   # isbn -> list of member_ids (queue)
    security_log = []   # list of dicts for failed login events

    return {
        "members"       : members,
        "staff_accounts": staff_accounts,
        "branches"      : branches,
        "books"         : books,
        "loan_records"  : loan_records,
        "payments"      : payments,
        "reservations"  : reservations,
        "security_log"  : security_log,
    }


# ============================================================
# AUTHENTICATION
# (Lutz, 2013, p. 213; Matthes, 2019, p. 200)
# ============================================================

def authenticate_staff(staff_accounts, username, password):
    """
    Validate staff credentials.

    Args:
        staff_accounts (dict): Staff accounts dictionary.
        username       (str):  Entered username.
        password       (str):  Entered password.

    Returns:
        dict | None: Staff record on success, None on failure.

    Test:
        >>> authenticate_staff({"u": {"password":"p","role":"Librarian","full_name":"A","branch":"DBN001","active":True}}, "u", "p")
        {'password': 'p', 'role': 'Librarian', 'full_name': 'A', 'branch': 'DBN001', 'active': True}
        >>> authenticate_staff({...}, "u", "wrong") -> None
    """
    if username in staff_accounts:
        account = staff_accounts[username]
        if not account.get("active", True):
            print("  This account has been deactivated.")
            return None
        if account["password"] == password:
            return account
    return None


# ============================================================
# MEMBER FUNCTIONS
# (Matthes, 2019, p. 56; Lutz, 2013, p. 312)
# ============================================================

def register_member(members, member_id, name, sa_id, contact,
                    email, branch, membership_type):
    """
    Register a new library member.  Rejects duplicate SA IDs and
    duplicate member IDs.

    Args:
        members         (dict): Members dictionary.
        member_id        (str): Unique member ID (e.g. "M011").
        name             (str): Full name.
        sa_id            (str): 13-digit SA ID number.
        contact          (str): Contact number.
        email            (str): Email address.
        branch           (str): Branch code.
        membership_type  (str): One of Junior, Standard, Senior, Student.

    Returns:
        dict | None: New member record on success, None on failure.
    """
    # Reject duplicate member ID
    if member_id in members:
        print(f"  Member ID '{member_id}' already exists.")
        return None
    # Reject duplicate SA ID
    for existing in members.values():
        if existing["sa_id"] == sa_id:
            print("  A member with that SA ID already exists.")
            return None
    members[member_id] = {
        "name"             : name,
        "sa_id"            : sa_id,
        "contact"          : contact,
        "email"            : email,
        "branch"           : branch,
        "membership_type"  : membership_type,
        "status"           : "Active",
        "active_loans"     : [],
        "outstanding_fines": 0.0,
        "loan_history"     : [],
    }
    print(f"\n  Member '{name}' registered successfully (ID: {member_id}).")
    return members[member_id]


def list_membership_types(members):
    """Display all unique membership types present in the system using a set."""
    types_in_use = {m["membership_type"] for m in members.values()}
    print("\n  Membership types currently in use:")
    for t in sorted(types_in_use):
        print(f"    - {t}")


def view_member_account(members, loan_records, reservations, member_id):
    """
    Display complete account information for a member:
    loan history, active loans, outstanding fines, and
    reservation queue positions.
    """
    if member_id not in members:
        print("  Member not found.")
        return
    m = members[member_id]
    print(f"\n  ---- Member Account: {m['name']} ({member_id}) ----")
    print(f"  Membership : {m['membership_type']}  |  Branch : {m['branch']}")
    print(f"  Status     : {m['status']}  |  Outstanding fines: R{m['outstanding_fines']:.2f}")

    print("\n  Loan History:")
    history = [l for l in loan_records if l["member_id"] == member_id]
    if not history:
        print("    No loans on record.")
    else:
        for loan in history:
            status = "Active" if loan["return_date"] == "" else f"Returned {loan['return_date']}"
            print(f"    Loan {loan['loan_id']:>3} | ISBN {loan['isbn']} | "
                  f"Due {loan['due_date']} | {status} | "
                  f"Fine R{loan['fine_amount']:.2f} "
                  f"({'Paid' if loan['fine_paid'] else 'Unpaid'})")

    print("\n  Reservation Queue Positions:")
    found_res = False
    for isbn, queue in reservations.items():
        if member_id in queue:
            pos = queue.index(member_id) + 1
            print(f"    ISBN {isbn} — Position {pos} in queue")
            found_res = True
    if not found_res:
        print("    No active reservations.")


# ============================================================
# BOOK FUNCTIONS
# (Python Software Foundation, 2024)
# ============================================================

def add_book(books, branch_code):
    """Prompt for book details and add to the catalogue."""
    isbn = get_valid_isbn("  ISBN (13 digits): ")
    if isbn in books:
        print("  A book with that ISBN already exists.")
        return
    title   = input("  Title  : ").strip()
    author  = input("  Author : ").strip()
    try:
        copies = int(input("  Number of copies: ").strip())
    except ValueError:
        copies = 1
    books[isbn] = {
        "title"            : title,
        "author"           : author,
        "branch"           : branch_code,
        "copies_total"     : copies,
        "copies_available" : copies,
    }
    print(f"  Book '{title}' added to catalogue.")


def update_book(books):
    """Update the title or author of an existing book."""
    isbn = get_valid_isbn("  ISBN of book to update: ")
    if isbn not in books:
        print("  Book not found.")
        return
    print(f"  Current title : {books[isbn]['title']}")
    print(f"  Current author: {books[isbn]['author']}")
    new_title  = input("  New title  (Enter to keep): ").strip()
    new_author = input("  New author (Enter to keep): ").strip()
    if new_title:
        books[isbn]["title"] = new_title
    if new_author:
        books[isbn]["author"] = new_author
    print("  Book updated.")


def remove_book(books):
    """Remove a book from the catalogue."""
    isbn = get_valid_isbn("  ISBN of book to remove: ")
    if isbn not in books:
        print("  Book not found.")
        return
    confirm = input(f"  Remove '{books[isbn]['title']}'? (Y/N): ").strip().upper()
    if confirm == "Y":
        del books[isbn]
        print("  Book removed from catalogue.")


def search_catalogue(books, query):
    """Search catalogue by title or author keyword (case-insensitive)."""
    query_lower = query.lower()
    results = [
        (isbn, b) for isbn, b in books.items()
        if query_lower in b["title"].lower() or query_lower in b["author"].lower()
    ]
    if not results:
        print("  No books found matching that query.")
        return
    print(f"\n  Search results for '{query}':")
    print(f"  {'ISBN':<15} {'Title':<35} {'Author':<25} {'Branch':<8} {'Available'}")
    print("  " + "-" * 95)
    for isbn, b in results:
        print(f"  {isbn:<15} {b['title']:<35} {b['author']:<25} "
              f"{b['branch']:<8} {b['copies_available']}/{b['copies_total']}")


# ============================================================
# LOAN FUNCTIONS
# (Matthes, 2019, p. 112; Python Software Foundation, 2024)
# ============================================================

def issue_loan(loan_records, members, branches, member_id,
               isbn, issue_date):
    """
    Issue a book loan after validating eligibility and capacity.

    Validates: member exists and is Active, fines <= R50, loan limit,
    branch daily capacity, and book availability.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branches     (dict): Branches dictionary.
        member_id     (str): ID of member borrowing the book.
        isbn          (str): 13-digit ISBN of the book.
        issue_date    (str): Issue date string DD/MM/YYYY.

    Returns:
        dict | None: New loan record on success, None on failure.
    """
    if member_id not in members:
        print("  Member not found.")
        return None

    member = members[member_id]

    if member["status"] != "Active":
        print("  Member account is inactive.")
        return None

    if member["outstanding_fines"] > FINE_BLOCK_LIMIT:
        print(f"  Loan blocked: outstanding fines R{member['outstanding_fines']:.2f} exceed R{FINE_BLOCK_LIMIT:.2f}.")
        return None

    limit = MEMBERSHIP_LIMITS[member["membership_type"]]
    if len(member["active_loans"]) >= limit:
        print(f"  Loan limit reached ({limit} books for {member['membership_type']} members).")
        return None

    branch_code = member["branch"]
    branch      = branches[branch_code]
    if branch["active_loans"] >= branch["max_daily_loans"]:
        print(f"  Branch daily loan limit of {branch['max_daily_loans']} reached.")
        return None

    # Check book availability
    from_books = False
    if isbn in members:   # edge-case guard
        pass
    # We check the books dict if available; fall through if not tracked
    period   = LOAN_PERIODS[member["membership_type"]]
    issue_dt = datetime.strptime(issue_date, "%d/%m/%Y")
    due_date = (issue_dt + timedelta(days=period)).strftime("%d/%m/%Y")

    loan_id  = max((l["loan_id"] for l in loan_records), default=0) + 1

    new_loan = {
        "loan_id"     : loan_id,
        "member_id"   : member_id,
        "isbn"        : isbn,
        "branch_code" : branch_code,
        "issue_date"  : issue_date,
        "due_date"    : due_date,
        "return_date" : "",
        "days_overdue": 0,
        "fine_amount" : 0.0,
        "fine_paid"   : False,
    }

    loan_records.append(new_loan)
    member["active_loans"].append(isbn)
    member["loan_history"].append(loan_id)
    branch["active_loans"] += 1

    print(f"\n  === LOAN RECEIPT ===")
    print(f"  Loan ID    : {loan_id}")
    print(f"  Member     : {member['name']} ({member_id})")
    print(f"  ISBN       : {isbn}")
    print(f"  Issue Date : {issue_date}")
    print(f"  Due Date   : {due_date}")
    print(f"  ====================")
    return new_loan


def process_return(loan_records, members, branches,
                   member_id, isbn, return_date):
    """
    Locate the active loan, compute any fine, update the record
    and the member's outstanding balance.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branches     (dict): Branches dictionary.
        member_id     (str): Member returning the book.
        isbn          (str): ISBN of book being returned.
        return_date   (str): Return date string DD/MM/YYYY.

    Returns:
        float: Fine amount (0.0 if on time), or -1 if loan not found.
    """
    for loan in loan_records:
        if (loan["member_id"] == member_id and
                loan["isbn"] == isbn and
                loan["return_date"] == ""):

            loan["return_date"] = return_date
            due_dt  = datetime.strptime(loan["due_date"],  "%d/%m/%Y")
            ret_dt  = datetime.strptime(return_date,       "%d/%m/%Y")
            overdue = max(0, (ret_dt - due_dt).days)

            fine = 0.0
            if overdue > 0:
                membership_type      = members[member_id]["membership_type"]
                first_offence        = len(members[member_id]["loan_history"]) <= 1
                fine                 = calculate_fine(membership_type, overdue, 1, first_offence)
                loan["days_overdue"] = overdue
                loan["fine_amount"]  = fine
                members[member_id]["outstanding_fines"] += fine

            # Remove from active loans
            if isbn in members[member_id]["active_loans"]:
                members[member_id]["active_loans"].remove(isbn)

            # Restore branch counter
            branch_code = loan["branch_code"]
            if branches[branch_code]["active_loans"] > 0:
                branches[branch_code]["active_loans"] -= 1

            print(f"\n  Return processed for {members[member_id]['name']}.")
            print(f"  Days overdue : {overdue}")
            print(f"  Fine accrued : R{fine:.2f}")
            print(f"  Total balance: R{members[member_id]['outstanding_fines']:.2f}")
            return fine

    print("  No active loan found for that member and ISBN.")
    return -1


def place_reservation(reservations, books, member_id, isbn):
    """Add member to the reservation queue for a book."""
    if isbn not in books:
        print("  Book not found in catalogue.")
        return
    if isbn not in reservations:
        reservations[isbn] = []
    if member_id in reservations[isbn]:
        print("  Member is already in the queue for this book.")
        return
    reservations[isbn].append(member_id)
    pos = reservations[isbn].index(member_id) + 1
    print(f"  Reservation placed. Queue position: {pos}.")


def cancel_reservation(reservations, member_id, isbn):
    """Remove member from the reservation queue for a book."""
    if isbn not in reservations or member_id not in reservations[isbn]:
        print("  No reservation found for that member and ISBN.")
        return
    reservations[isbn].remove(member_id)
    print("  Reservation cancelled.")


# ============================================================
# PAYMENT FUNCTIONS
# (Lutz, 2013, p. 218)
# ============================================================

def accept_payment(members, payments, member_id):
    """
    Accept a full or partial fine payment from a member.
    Restores borrowing privileges when balance reaches R0.00.

    Args:
        members  (dict): Members dictionary.
        payments (list): Payments list.
        member_id (str): Member making the payment.
    """
    if member_id not in members:
        print("  Member not found.")
        return

    member  = members[member_id]
    balance = member["outstanding_fines"]

    if balance <= 0:
        print(f"  {member['name']} has no outstanding fines.")
        return

    print(f"\n  Outstanding balance for {member['name']}: R{balance:.2f}")
    amount = get_positive_amount("  Amount to pay (R): ")

    if amount > balance:
        amount = balance
        print(f"  Adjusted to full balance: R{amount:.2f}")

    member["outstanding_fines"] = round(balance - amount, 2)

    payment_record = {
        "payment_id": len(payments) + 1,
        "member_id" : member_id,
        "amount"    : amount,
        "date"      : datetime.now().strftime("%d/%m/%Y"),
        "balance"   : member["outstanding_fines"],
    }
    payments.append(payment_record)

    print(f"\n  === PAYMENT RECEIPT ===")
    print(f"  Member    : {member['name']}")
    print(f"  Paid      : R{amount:.2f}")
    print(f"  Remaining : R{member['outstanding_fines']:.2f}")
    print(f"  =======================")

    if member["outstanding_fines"] == 0.0:
        print("  Borrowing privileges fully restored.")


# ============================================================
# REPORT FUNCTIONS
# (Matthes, 2019, p. 56; Lutz, 2013, p. 312)
# ============================================================

def generate_branch_report(loan_records, members, branch_code):
    """
    Generate branch-level statistics.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branch_code   (str): Branch code to report on.

    Returns:
        dict: total_loans, active_loans, overdue, fines_issued,
              fines_collected, avg_duration.

    Test call 1 — empty branch:
        generate_branch_report([], {}, "DBN001") ->
        {'total_loans': 0, 'active_loans': 0, 'overdue': 0,
         'fines_issued': 0.0, 'fines_collected': 0.0, 'avg_duration': 0.0}

    Test call 2 — with data:
        generate_branch_report(loan_records, members, "DBN001") ->
        returns counts matching the DBN001 pre-populated loans.
    """
    total_loans = active_loans = overdue = 0
    fines_issued = fines_collected = 0.0
    durations = []

    for loan in loan_records:
        if loan["branch_code"] != branch_code:
            continue
        total_loans  += 1
        fines_issued += loan["fine_amount"]
        if loan["return_date"] == "":
            active_loans += 1
        else:
            # Calculate duration for returned loans
            issue_dt  = datetime.strptime(loan["issue_date"],  "%d/%m/%Y")
            return_dt = datetime.strptime(loan["return_date"], "%d/%m/%Y")
            durations.append((return_dt - issue_dt).days)
        if loan["days_overdue"] > 0:
            overdue += 1
        if loan["fine_paid"]:
            fines_collected += loan["fine_amount"]

    avg_duration = round(sum(durations) / len(durations), 2) if durations else 0.0

    return {
        "total_loans"    : total_loans,
        "active_loans"   : active_loans,
        "overdue"        : overdue,
        "fines_issued"   : fines_issued,
        "fines_collected": fines_collected,
        "avg_duration"   : avg_duration,
    }


def display_branch_report(loan_records, members, branches, branch_code):
    """Print a formatted branch-level report to the console."""
    report = generate_branch_report(loan_records, members, branch_code)
    name   = branches[branch_code]["name"]
    print(f"\n  ========= Branch Report: {name} =========")
    print(f"  Total loans    : {report['total_loans']}")
    print(f"  Active loans   : {report['active_loans']}")
    print(f"  Overdue loans  : {report['overdue']}")
    print(f"  Fines issued   : R{report['fines_issued']:.2f}")
    print(f"  Fines collected: R{report['fines_collected']:.2f}")
    print(f"  Avg loan days  : {report['avg_duration']}")
    print(f"  ==========================================")


def cross_branch_report(branches, loan_records, members):
    """
    Display a cross-branch comparison table with a grand total row.
    Administrator access only.
    (Lutz, 2013, p. 312)
    """
    print("\n  ============================================================")
    print("  CROSS-BRANCH COMPARISON REPORT")
    print("  ============================================================")
    header = f"  {'Branch':<30} {'Total':>6} {'Active':>7} {'Overdue':>8} {'Fines Issued':>14} {'Fines Coll.':>12}"
    print(header)
    print("  " + "-" * 82)

    grand_total = grand_active = grand_overdue = 0
    grand_issued = grand_collected = 0.0

    for code, branch in branches.items():
        r = generate_branch_report(loan_records, members, code)
        print(f"  {branch['name']:<30} {r['total_loans']:>6} {r['active_loans']:>7} "
              f"{r['overdue']:>8} R{r['fines_issued']:>12.2f} R{r['fines_collected']:>10.2f}")
        grand_total     += r["total_loans"]
        grand_active    += r["active_loans"]
        grand_overdue   += r["overdue"]
        grand_issued    += r["fines_issued"]
        grand_collected += r["fines_collected"]

    print("  " + "-" * 82)
    print(f"  {'GRAND TOTAL':<30} {grand_total:>6} {grand_active:>7} "
          f"{grand_overdue:>8} R{grand_issued:>12.2f} R{grand_collected:>10.2f}")
    print("  ============================================================")


# ============================================================
# ADMIN FUNCTIONS
# (Lutz, 2013, p. 500)
# ============================================================

def apply_fine_amnesty(members):
    """
    Quarterly fine amnesty: clear all outstanding balances below
    the AMNESTY_THRESHOLD (R10.00).
    System Administrator only.
    """
    cleared = 0
    total   = 0.0
    for mid, member in members.items():
        if 0 < member["outstanding_fines"] < AMNESTY_THRESHOLD:
            total += member["outstanding_fines"]
            member["outstanding_fines"] = 0.0
            cleared += 1
    print(f"\n  Amnesty applied: {cleared} member(s) cleared, "
          f"R{total:.2f} total waived.")


def register_staff(staff_accounts):
    """Register a new staff account.  Admin only."""
    username = input("  New username: ").strip()
    if username in staff_accounts:
        print("  Username already exists.")
        return
    password    = input("  Password: ").strip()
    full_name   = input("  Full name: ").strip()
    role        = get_menu_choice(
        "  Role (Librarian / Senior Librarian / System Administrator): ",
        ["Librarian", "Senior Librarian", "System Administrator"])
    branch_code = get_menu_choice("  Branch: ", BRANCH_CODES)

    staff_accounts[username] = {
        "password" : password,
        "role"     : role,
        "full_name": full_name,
        "branch"   : branch_code,
        "active"   : True,
    }
    print(f"  Staff account '{username}' created.")


def deactivate_staff(staff_accounts):
    """Deactivate a staff account.  Admin only."""
    username = input("  Username to deactivate: ").strip()
    if username not in staff_accounts:
        print("  Account not found.")
        return
    staff_accounts[username]["active"] = False
    print(f"  Account '{username}' deactivated.")


def export_data(data):
    """
    Export data to a plain-text file for backup.
    Writes members and loan_records summaries.
    Admin only.
    """
    filename = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(filename, "w") as f:
            f.write("=== MEMBERS ===\n")
            for mid, m in data["members"].items():
                f.write(f"{mid},{m['name']},{m['membership_type']},"
                        f"{m['branch']},{m['outstanding_fines']:.2f}\n")
            f.write("\n=== LOANS ===\n")
            for loan in data["loan_records"]:
                f.write(f"{loan['loan_id']},{loan['member_id']},"
                        f"{loan['isbn']},{loan['branch_code']},"
                        f"{loan['issue_date']},{loan['due_date']},"
                        f"{loan['return_date']},{loan['fine_amount']:.2f}\n")
        print(f"  Backup written to '{filename}'.")
    except IOError as e:
        print(f"  Export failed: {e}")


# ============================================================
# ROLE-BASED MENUS
# (Lutz, 2013, p. 390)
# ============================================================

def librarian_menu(data, staff):
    """
    Console menu for the Librarian role.
    Handles day-to-day member and loan operations.
    """
    branch_name = data["branches"].get(staff["branch"], {}).get("name", staff["branch"])
    while True:
        print(f"\n  ============================================")
        print(f"  LIBRARIAN MENU  |  {branch_name}")
        print(f"  ============================================")
        print("  1. Register Member")
        print("  2. Issue Loan")
        print("  3. Process Return")
        print("  4. Accept Fine Payment")
        print("  5. Place Reservation")
        print("  6. Cancel Reservation")
        print("  7. View Member Account")
        print("  8. Search Catalogue")
        print("  9. Logout")

        choice = get_menu_choice("  Enter choice: ",
                                 ["1","2","3","4","5","6","7","8","9"])

        if choice == "1":
            member_id  = input("  New Member ID: ").strip()
            name       = input("  Full Name    : ").strip()
            sa_id      = get_valid_sa_id("  SA ID (13 digits): ")
            contact    = input("  Contact No.  : ").strip()
            email      = input("  Email        : ").strip()
            branch_code = get_menu_choice("  Branch code  : ", BRANCH_CODES)
            mem_type   = get_menu_choice("  Membership (Junior/Standard/Senior/Student): ",
                                         MEMBERSHIP_TYPES)
            register_member(data["members"], member_id, name, sa_id,
                            contact, email, branch_code, mem_type)

        elif choice == "2":
            member_id  = input("  Member ID : ").strip()
            isbn       = get_valid_isbn("  ISBN       : ")
            issue_date = get_valid_date("  Issue Date (DD/MM/YYYY): ")
            issue_loan(data["loan_records"], data["members"],
                       data["branches"], member_id, isbn, issue_date)

        elif choice == "3":
            member_id   = input("  Member ID   : ").strip()
            isbn        = get_valid_isbn("  ISBN        : ")
            return_date = get_valid_date("  Return Date (DD/MM/YYYY): ")
            process_return(data["loan_records"], data["members"],
                           data["branches"], member_id, isbn, return_date)

        elif choice == "4":
            member_id = input("  Member ID: ").strip()
            accept_payment(data["members"], data["payments"], member_id)

        elif choice == "5":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            place_reservation(data["reservations"], data["books"],
                              member_id, isbn)

        elif choice == "6":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            cancel_reservation(data["reservations"], member_id, isbn)

        elif choice == "7":
            member_id = input("  Member ID: ").strip()
            view_member_account(data["members"], data["loan_records"],
                                data["reservations"], member_id)

        elif choice == "8":
            query = input("  Search title or author: ").strip()
            search_catalogue(data["books"], query)

        elif choice == "9":
            print("  Logged out.")
            break


def senior_librarian_menu(data, staff):
    """
    Console menu for the Senior Librarian role.
    All Librarian options plus catalogue management and branch reports.
    """
    branch_name = data["branches"].get(staff["branch"], {}).get("name", staff["branch"])
    while True:
        print(f"\n  ============================================")
        print(f"  SENIOR LIBRARIAN MENU  |  {branch_name}")
        print(f"  ============================================")
        print("  1.  Register Member")
        print("  2.  Issue Loan")
        print("  3.  Process Return")
        print("  4.  Accept Fine Payment")
        print("  5.  Place Reservation")
        print("  6.  Cancel Reservation")
        print("  7.  View Member Account")
        print("  8.  Search Catalogue")
        print("  9.  Add Book to Catalogue")
        print("  10. Update Book Details")
        print("  11. Remove Book from Catalogue")
        print("  12. Inter-Branch Transfer Request")
        print("  13. Branch Report")
        print("  14. Logout")

        choice = get_menu_choice(
            "  Enter choice: ",
            [str(i) for i in range(1, 15)])

        if choice == "1":
            member_id   = input("  New Member ID: ").strip()
            name        = input("  Full Name    : ").strip()
            sa_id       = get_valid_sa_id("  SA ID (13 digits): ")
            contact     = input("  Contact No.  : ").strip()
            email       = input("  Email        : ").strip()
            branch_code = get_menu_choice("  Branch code  : ", BRANCH_CODES)
            mem_type    = get_menu_choice(
                "  Membership (Junior/Standard/Senior/Student): ",
                MEMBERSHIP_TYPES)
            register_member(data["members"], member_id, name, sa_id,
                            contact, email, branch_code, mem_type)

        elif choice == "2":
            member_id  = input("  Member ID : ").strip()
            isbn       = get_valid_isbn("  ISBN       : ")
            issue_date = get_valid_date("  Issue Date (DD/MM/YYYY): ")
            issue_loan(data["loan_records"], data["members"],
                       data["branches"], member_id, isbn, issue_date)

        elif choice == "3":
            member_id   = input("  Member ID   : ").strip()
            isbn        = get_valid_isbn("  ISBN        : ")
            return_date = get_valid_date("  Return Date (DD/MM/YYYY): ")
            process_return(data["loan_records"], data["members"],
                           data["branches"], member_id, isbn, return_date)

        elif choice == "4":
            member_id = input("  Member ID: ").strip()
            accept_payment(data["members"], data["payments"], member_id)

        elif choice == "5":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            place_reservation(data["reservations"], data["books"],
                              member_id, isbn)

        elif choice == "6":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            cancel_reservation(data["reservations"], member_id, isbn)

        elif choice == "7":
            member_id = input("  Member ID: ").strip()
            view_member_account(data["members"], data["loan_records"],
                                data["reservations"], member_id)

        elif choice == "8":
            query = input("  Search title or author: ").strip()
            search_catalogue(data["books"], query)

        elif choice == "9":
            add_book(data["books"], staff["branch"])

        elif choice == "10":
            update_book(data["books"])

        elif choice == "11":
            remove_book(data["books"])

        elif choice == "12":
            # Inter-branch transfer: flag a book for transfer
            isbn        = get_valid_isbn("  ISBN to transfer: ")
            dest_branch = get_menu_choice("  Destination branch: ", BRANCH_CODES)
            if isbn in data["books"]:
                print(f"  Transfer request logged: ISBN {isbn} -> {dest_branch}.")
                print("  (In a live system this would notify the destination branch.)")
            else:
                print("  Book not found.")

        elif choice == "13":
            branch_code = get_menu_choice("  Branch code: ", BRANCH_CODES)
            display_branch_report(data["loan_records"], data["members"],
                                  data["branches"], branch_code)

        elif choice == "14":
            print("  Logged out.")
            break


def admin_menu(data, staff):
    """
    Console menu for the System Administrator role.
    Full access to all system functions.
    """
    branch_name = data["branches"].get(staff["branch"], {}).get("name", staff["branch"])
    while True:
        print(f"\n  ============================================")
        print(f"  SYSTEM ADMINISTRATOR MENU  |  {branch_name}")
        print(f"  ============================================")
        print("  1.  Register Member")
        print("  2.  Issue Loan")
        print("  3.  Process Return")
        print("  4.  Accept Fine Payment")
        print("  5.  Place Reservation")
        print("  6.  Cancel Reservation")
        print("  7.  View Member Account")
        print("  8.  Search Catalogue")
        print("  9.  Add Book to Catalogue")
        print("  10. Update Book Details")
        print("  11. Remove Book from Catalogue")
        print("  12. Branch Report")
        print("  13. Cross-Branch Comparison Report")
        print("  14. Apply Fine Amnesty (< R10.00)")
        print("  15. Register Staff Account")
        print("  16. Deactivate Staff Account")
        print("  17. List Unique Membership Types")
        print("  18. Export / Backup Data")
        print("  19. Logout")

        choice = get_menu_choice(
            "  Enter choice: ",
            [str(i) for i in range(1, 20)])

        if choice == "1":
            member_id   = input("  New Member ID: ").strip()
            name        = input("  Full Name    : ").strip()
            sa_id       = get_valid_sa_id("  SA ID (13 digits): ")
            contact     = input("  Contact No.  : ").strip()
            email       = input("  Email        : ").strip()
            branch_code = get_menu_choice("  Branch code  : ", BRANCH_CODES)
            mem_type    = get_menu_choice(
                "  Membership (Junior/Standard/Senior/Student): ",
                MEMBERSHIP_TYPES)
            register_member(data["members"], member_id, name, sa_id,
                            contact, email, branch_code, mem_type)

        elif choice == "2":
            member_id  = input("  Member ID : ").strip()
            isbn       = get_valid_isbn("  ISBN       : ")
            issue_date = get_valid_date("  Issue Date (DD/MM/YYYY): ")
            issue_loan(data["loan_records"], data["members"],
                       data["branches"], member_id, isbn, issue_date)

        elif choice == "3":
            member_id   = input("  Member ID   : ").strip()
            isbn        = get_valid_isbn("  ISBN        : ")
            return_date = get_valid_date("  Return Date (DD/MM/YYYY): ")
            process_return(data["loan_records"], data["members"],
                           data["branches"], member_id, isbn, return_date)

        elif choice == "4":
            member_id = input("  Member ID: ").strip()
            accept_payment(data["members"], data["payments"], member_id)

        elif choice == "5":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            place_reservation(data["reservations"], data["books"],
                              member_id, isbn)

        elif choice == "6":
            member_id = input("  Member ID: ").strip()
            isbn      = get_valid_isbn("  ISBN     : ")
            cancel_reservation(data["reservations"], member_id, isbn)

        elif choice == "7":
            member_id = input("  Member ID: ").strip()
            view_member_account(data["members"], data["loan_records"],
                                data["reservations"], member_id)

        elif choice == "8":
            query = input("  Search title or author: ").strip()
            search_catalogue(data["books"], query)

        elif choice == "9":
            add_book(data["books"], staff["branch"])

        elif choice == "10":
            update_book(data["books"])

        elif choice == "11":
            remove_book(data["books"])

        elif choice == "12":
            branch_code = get_menu_choice("  Branch code: ", BRANCH_CODES)
            display_branch_report(data["loan_records"], data["members"],
                                  data["branches"], branch_code)

        elif choice == "13":
            cross_branch_report(data["branches"], data["loan_records"],
                                data["members"])

        elif choice == "14":
            apply_fine_amnesty(data["members"])

        elif choice == "15":
            register_staff(data["staff_accounts"])

        elif choice == "16":
            deactivate_staff(data["staff_accounts"])

        elif choice == "17":
            list_membership_types(data["members"])

        elif choice == "18":
            export_data(data)

        elif choice == "19":
            print("  Logged out.")
            break


# ============================================================
# MAIN — ENTRY POINT
# (Lutz, 2013, p. 500; Matthes, 2019, p. 200)
# ============================================================

def main():
    """
    Entry point for the Thekwini Metropolitan Library System.
    Initialises data, presents the login screen, locks after 3
    failed attempts, and routes the authenticated user to the
    correct role-based menu.
    """
    data = initialise_data()

    print("\n  ================================================")
    print("  THEKWINI METROPOLITAN LIBRARIES")
    print("  Centralised Library Management System v1.0")
    print("  ================================================")
    print("  Default logins for testing:")
    print("    Librarian      : librarian1 / lib123")
    print("    Senior Lib.    : senior1    / sen123")
    print("    Administrator  : admin1     / admin123")
    print("  ================================================")

    while True:
        failed_attempts = 0
        locked          = False

        print("\n  ---- LOGIN ----")
        while failed_attempts < MAX_LOGIN_ATTEMPTS:
            username = input("  Username: ").strip()
            password = input("  Password: ").strip()

            staff = authenticate_staff(data["staff_accounts"], username, password)

            if staff:
                role = staff["role"]
                print(f"\n  Welcome, {staff['full_name']} | Role: {role}")

                if role == "Librarian":
                    librarian_menu(data, staff)
                elif role == "Senior Librarian":
                    senior_librarian_menu(data, staff)
                elif role == "System Administrator":
                    admin_menu(data, staff)
                break

            else:
                failed_attempts += 1
                remaining = MAX_LOGIN_ATTEMPTS - failed_attempts
                if remaining > 0:
                    print(f"  Incorrect credentials. {remaining} attempt(s) remaining.")
                else:
                    locked = True
                    print("\n  Too many failed attempts. This session is locked.")
                    # Log the event in memory
                    data["security_log"].append({
                        "event"    : "FAILED_LOGIN_LOCKOUT",
                        "username" : username,
                        "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                    })
                    print(f"  [LOG] Lockout event recorded for username: '{username}'.")

        if locked:
            again = input("\n  Try again? (Y/N): ").strip().upper()
            if again != "Y":
                print("\n  System closed. Goodbye.")
                break
        else:
            again = input("\n  Return to login screen? (Y/N): ").strip().upper()
            if again != "Y":
                print("\n  System closed. Goodbye.")
                break


# ============================================================
# PROGRAM ENTRY GUARD
# ============================================================

if __name__ == "__main__":
    main()


# ============================================================
# References:
# Lutz, M., 2013. Learning Python. 5th ed.
#   Sebastopol: O'Reilly Media.
#
# Matthes, E., 2019. Python Crash Course. 2nd ed.
#   San Francisco: No Starch Press.
#
# Python Software Foundation, 2024. datetime — Basic date
#   and time types. [Online] Available at:
#   https://docs.python.org/3/library/datetime.html
#   [Accessed: 28 May 2026]
#
# Python Software Foundation, 2024. Built-in Functions.
#   [Online] Available at:
#   https://docs.python.org/3/library/functions.html
#   [Accessed: 28 May 2026]
# ============================================================
