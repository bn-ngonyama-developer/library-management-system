# Name and Surname: Blessing Ngonyama\n# Student Number:   402606147\n# Module:           Introduction to Programming 500\n# Date:             02 June 2026\nfrom datetime import datetime

def generate_branch_report(loan_records, members, branch_code):
    """
    Generate branch-level statistics.

    Args:
        loan_records (list): All loan records.
        members      (dict): Members dictionary.
        branch_code   (str): Branch code to report on.

    Returns:
        dict: total_loans, active_loans, overdue, fines_issued,
              fines_collected, avg_duration.

    Test call 1 — empty branch:
        generate_branch_report([], {}, "DBN001") ->
        {'total_loans': 0, 'active_loans': 0, 'overdue': 0,
         'fines_issued': 0.0, 'fines_collected': 0.0, 'avg_duration': 0.0}

    Test call 2 — with data:
        generate_branch_report(loan_records, members, "DBN001") ->
        returns counts matching the DBN001 pre-populated loans.
    """
    total_loans = active_loans = overdue = 0
    fines_issued = fines_collected = 0.0
    durations = []

    for loan in loan_records:
        if loan["branch_code"] != branch_code:
            continue
        total_loans  += 1
        fines_issued += loan["fine_amount"]
        if loan["return_date"] == "":
            active_loans += 1
        else:
            # Calculate duration for returned loans
            issue_dt  = datetime.strptime(loan["issue_date"],  "%d/%m/%Y")
            return_dt = datetime.strptime(loan["return_date"], "%d/%m/%Y")
            durations.append((return_dt - issue_dt).days)
        if loan["days_overdue"] > 0:
            overdue += 1
        if loan["fine_paid"]:
            fines_collected += loan["fine_amount"]

    avg_duration = round(sum(durations) / len(durations), 2) if durations else 0.0

    return {
        "total_loans"    : total_loans,
        "active_loans"   : active_loans,
        "overdue"        : overdue,
        "fines_issued"   : fines_issued,
        "fines_collected": fines_collected,
        "avg_duration"   : avg_duration,
    }


def display_branch_report(loan_records, members, branches, branch_code):
    """Print a formatted branch-level report to the console."""
    report = generate_branch_report(loan_records, members, branch_code)
    name   = branches[branch_code]["name"]
    print(f"\n  ========= Branch Report: {name} =========")
    print(f"  Total loans    : {report['total_loans']}")
    print(f"  Active loans   : {report['active_loans']}")
    print(f"  Overdue loans  : {report['overdue']}")
    print(f"  Fines issued   : R{report['fines_issued']:.2f}")
    print(f"  Fines collected: R{report['fines_collected']:.2f}")
    print(f"  Avg loan days  : {report['avg_duration']}")
    print(f"  ==========================================")


def cross_branch_report(branches, loan_records, members):
    """
    Display a cross-branch comparison table with a grand total row.
    Administrator access only.
    (Lutz, 2013, p. 312)
    """
    print("\n  ============================================================")
    print("  CROSS-BRANCH COMPARISON REPORT")
    print("  ============================================================")
    header = f"  {'Branch':<30} {'Total':>6} {'Active':>7} {'Overdue':>8} {'Fines Issued':>14} {'Fines Coll.':>12}"
    print(header)
    print("  " + "-" * 82)

    grand_total = grand_active = grand_overdue = 0
    grand_issued = grand_collected = 0.0

    for code, branch in branches.items():
        r = generate_branch_report(loan_records, members, code)
        print(f"  {branch['name']:<30} {r['total_loans']:>6} {r['active_loans']:>7} "
              f"{r['overdue']:>8} R{r['fines_issued']:>12.2f} R{r['fines_collected']:>10.2f}")
        grand_total     += r["total_loans"]
        grand_active    += r["active_loans"]
        grand_overdue   += r["overdue"]
        grand_issued    += r["fines_issued"]
        grand_collected += r["fines_collected"]

    print("  " + "-" * 82)
    print(f"  {'GRAND TOTAL':<30} {grand_total:>6} {grand_active:>7} "
          f"{grand_overdue:>8} R{grand_issued:>12.2f} R{grand_collected:>10.2f}")
    print("  ============================================================")


