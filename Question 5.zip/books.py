# Name and Surname: Blessing Ngonyama
# Student Number:   402606147
# Module:           Introduction to Programming 500
# Date:             02 June 2026

from datetime import datetime


def get_valid_isbn(prompt):
    while True:
        value = input(prompt).strip()
        if value.isdigit() and len(value) == 13:
            return value
        print("  ISBN must be exactly 13 digits.")


def get_menu_choice(prompt, valid_options):
    while True:
        choice = input(prompt).strip()
        if choice in valid_options:
            return choice
        print(f"  Invalid option. Choose from: {', '.join(valid_options)}")


def add_book(books, branch_code):
    """Prompt for book details and add to the catalogue."""
    isbn = get_valid_isbn("  ISBN (13 digits): ")
    if isbn in books:
        print("  A book with that ISBN already exists.")
        return
    title   = input("  Title  : ").strip()
    author  = input("  Author : ").strip()
    try:
        copies = int(input("  Number of copies: ").strip())
    except ValueError:
        copies = 1
    books[isbn] = {
        "title"            : title,
        "author"           : author,
        "branch"           : branch_code,
        "copies_total"     : copies,
        "copies_available" : copies,
    }
    print(f"  Book '{title}' added to catalogue.")


def update_book(books):
    """Update the title or author of an existing book."""
    isbn = get_valid_isbn("  ISBN of book to update: ")
    if isbn not in books:
        print("  Book not found.")
        return
    print(f"  Current title : {books[isbn]['title']}")
    print(f"  Current author: {books[isbn]['author']}")
    new_title  = input("  New title  (Enter to keep): ").strip()
    new_author = input("  New author (Enter to keep): ").strip()
    if new_title:
        books[isbn]["title"] = new_title
    if new_author:
        books[isbn]["author"] = new_author
    print("  Book updated.")


def remove_book(books):
    """Remove a book from the catalogue."""
    isbn = get_valid_isbn("  ISBN of book to remove: ")
    if isbn not in books:
        print("  Book not found.")
        return
    confirm = input(f"  Remove '{books[isbn]['title']}'? (Y/N): ").strip().upper()
    if confirm == "Y":
        del books[isbn]
        print("  Book removed from catalogue.")


def search_catalogue(books, query):
    """Search catalogue by title or author keyword (case-insensitive)."""
    query_lower = query.lower()
    results = [
        (isbn, b) for isbn, b in books.items()
        if query_lower in b["title"].lower() or query_lower in b["author"].lower()
    ]
    if not results:
        print("  No books found matching that query.")
        return
    print(f"\n  Search results for '{query}':")
    print(f"  {'ISBN':<15} {'Title':<35} {'Author':<25} {'Branch':<8} {'Available'}")
    print("  " + "-" * 95)
    for isbn, b in results:
        print(f"  {isbn:<15} {b['title']:<35} {b['author']:<25} "
              f"{b['branch']:<8} {b['copies_available']}/{b['copies_total']}")


